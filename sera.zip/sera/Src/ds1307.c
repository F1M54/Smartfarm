/*
 * ds1307.c
 *
 *  Created on: Dec 6, 2023
 *      Author: Atakan
 */

#include "ds1307.h"
#include "main.h"
#include "stdbool.h"

I2C_HandleTypeDef *i2cDS1307;

/* Init the RTC DS1307 for starting the clock*/
void initDS1307(I2C_HandleTypeDef *hi2c) {
	i2cDS1307 = hi2c;
	startDS1307(true);
}

/* Start to RTC DS1307 if start -> TRUE then start, if start -> FALSE,then stop*/
void startDS1307(bool start) {
	uint8_t clock = (!start ? 1 << 7 : 0);
	setDS1307(RTC_SECOND, clock | (getDS1307(RTC_SECOND) & 0x7f));
}


/*
 * State of the RTC DS1307, it checks whether time starts or not start
 * 0x80 = 10000000, it is used for protecting the 7th bit, then zeros the other bits.
 * then it shifts 7 time to right, then the function returns 1 or 0.
 * it is used for flag.
 * */

uint8_t stateDS1307(void) {
	return (getDS1307(RTC_SECOND) & 0x80) >> 7;
}


/* Sets the bytes to targeted register of RTC
 *	registerDS -> address of register
 * 	value -> value in the register
 * 	*/
void setDS1307(uint8_t registerDS, uint8_t value) {
	uint8_t byteRaw[2] = {registerDS, value};
	HAL_I2C_Master_Transmit(i2cDS1307, RTC_I2C, byteRaw, 2, RTC_TIMEOUT);

}

/* gets the byte in targeted register of RTC
 * registerDS -> reg address
 * it returns the value of in the register.
 * */
uint8_t getDS1307(uint8_t registerDS) {
	uint8_t value;
	HAL_I2C_Master_Transmit(i2cDS1307, RTC_I2C, &registerDS, 1, RTC_TIMEOUT);
	HAL_I2C_Master_Receive(i2cDS1307, RTC_I2C, &value, 1, RTC_TIMEOUT);
	return value;
}

/*
 * set the timezone to RTC
 * the format is 12 to +12
 * */
void setTIMEZONE(int8_t hour) {
	setDS1307(RTC_UTC_HOUR, hour);
}

/*
 * it converts the binary value in registers to decimal number
 * range is 0 to 255
 * */
uint16_t convertDEC(uint16_t binaryNum) {
	return (((binaryNum & 0xf0) >> 4) * 10) + (binaryNum & 0x0f);
}

/*
 * it converts the decimal valu to binary number for registers.
 * */
uint16_t convertBCD(uint16_t decimalNum) {
		return (decimalNum % 10 + ((decimalNum / 10) << 4));
	}

/*	current day in RTC
 * 	the format is 1 to 31.
 * */
uint8_t dayDS1307(uint8_t *day) {
	*day = convertDEC(getDS1307(RTC_DATE));
}

/* current month in RTC
 * range is 1 to 12.
 * */
uint8_t monthDS1307(uint8_t *month) {
	*month = convertDEC(getDS1307(RTC_MONTH));
}

/* current year in RTC
 * year format is 2099 to 2023
 * */
uint16_t yearDS1307(uint16_t *year) {
	uint16_t century = getDS1307(RTC_CENTURY) * 100;
	*year = convertDEC(getDS1307(RTC_YEAR)) + century;
}

/*
 * current hour as a format 24h in RTC
 * 0x3F equals to "00111111". it is used for only protecting the 6 bit at the left.
 * upside setting is used for AM/PM configuration.
 * */
uint8_t hourDS1307(uint8_t *hour) {
	*hour = convertDEC(getDS1307(RTC_HOUR) & 0x3F);
}

/*
 * current minute in RTC
 * */
uint8_t minDS1307(uint8_t *minute){
	*minute = convertDEC(getDS1307(RTC_MINUTE));
}

/* current seconds in RTC
 * */
uint8_t secDS1307(uint8_t *second){
	*second = convertDEC(getDS1307(RTC_SECOND) & 0x7F);
}

/*
 * it gets the timezone in RTC
 * */
uint8_t timezoneDS1307(uint8_t *timezone) {
	*timezone = getDS1307(RTC_UTC_HOUR);
}

/*
 * set the day to RTC
 * format is 1 - 31
 * */
void setDAY(uint8_t day) {
	setDS1307(RTC_DATE, convertBCD(day));
}

/*
 * set the month to RTC
 * the format is 1 - 12
 * */
void setMONTH(uint8_t month) {
	setDS1307(RTC_MONTH, convertBCD(month));
}

/*
 * set the year to RTC
 * the format is 2000 - 2099
 * the calculation of year formula is used.
 * */
void setYEAR(uint16_t year) {
	setDS1307(RTC_CENTURY, year / 100);
	setDS1307(RTC_YEAR, convertBCD(year % 100));
}

/*
 * set the hour to RTC
 * the format is 0 - 23
 * */
void setHOUR(uint8_t hour) {
	setDS1307(RTC_HOUR, convertBCD(hour & 0x3f));
}

/*
 * set the minute to RTC
 * the format is 0 - 59
 * */
void setMINUTE(uint8_t minute) {
	setDS1307(RTC_MINUTE, convertBCD(minute));
}

/*
 * set the second to RTC
 * the format is 0 - 59
 * */
void setSECONDS(uint8_t second) {
	uint8_t ch = stateDS1307();
	setDS1307(RTC_SECOND, convertBCD(second | ch));
}

