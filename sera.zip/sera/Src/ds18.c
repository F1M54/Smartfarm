/*
 * ds18.c
 *
 *  Created on: Nov 24, 2023
 *      Author: Atakan
 *      add a pull up 4.7k resistor between data and vcc pin
 */
#include "main.h"
#include "ds18.h"

uint8_t Temp_byte1,Temp_byte2;
uint16_t TEMP;
float Temperature = 0;
uint8_t Presence = 0;

void outputSet(GPIO_TypeDef *GPIOx, uint16_t pin){
	GPIO_InitTypeDef ds;
	ds.Pin = pin;
	ds.Mode = GPIO_MODE_OUTPUT_PP;
	ds.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOx, &ds);
}

void inputSet(GPIO_TypeDef *GPIOx, uint16_t pin){
	GPIO_InitTypeDef ds;
	ds.Pin = pin;
	ds.Mode = GPIO_MODE_INPUT;
	ds.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOx, &ds);
}


uint8_t startDS(void){
	uint8_t response = 0;
	outputSet(DS18B20_PORT, DS18B20_PIN);
	HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN,0);
	delay(480);

	inputSet(DS18B20_PORT, DS18B20_PIN);
	delay(80);

	if(!(HAL_GPIO_ReadPin(DS18B20_PORT, DS18B20_PIN))){
		response = 1;
	}
	else{
		response = -1;
	}
	delay(400);
	return response;
}

void writeDS(uint8_t data){
	outputSet(DS18B20_PORT, DS18B20_PIN);
	for(int i=0;i<8;i++){

		if((data&(1<<i))!=0){
			outputSet(DS18B20_PORT, DS18B20_PIN);
			HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN,0);
			delay(1);

			inputSet(DS18B20_PORT, DS18B20_PIN);
			delay(60);
		}
		else {
			outputSet(DS18B20_PORT, DS18B20_PIN);
			HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN,0);
			delay(60);
			inputSet(DS18B20_PORT, DS18B20_PIN);
		}

	}
}

uint8_t readDS(void){

	uint8_t value = 0;
	inputSet(DS18B20_PORT, DS18B20_PIN);

	for(int i = 0; i<8;i++){
		outputSet(DS18B20_PORT, DS18B20_PIN);
		HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN,0);
		delay(2);

		inputSet(DS18B20_PORT, DS18B20_PIN);
		if(HAL_GPIO_ReadPin(DS18B20_PORT, DS18B20_PIN)){

			value|= 1<<i;
		}
		delay(60);
	}
	return value;
}
void readWaterTemp(float *temperature){
		Presence = startDS();
		HAL_Delay(1);
		writeDS(0xCC);  // skip ROM
		writeDS(0x44);  // convert t
		HAL_Delay(800);

		Presence = startDS();
		HAL_Delay(1);
		writeDS(0xCC);  // skip ROM
		writeDS(0xBE);  // Read Scratch-pad

		Temp_byte1 = readDS();
		Temp_byte2 = readDS();
		TEMP = (Temp_byte2<<8)|(Temp_byte1);
		*temperature = (float) TEMP/16;
		HAL_Delay(3000);
}
