/*
 * isik.c
 *
 *  Created on: Dec 8, 2023
 *      Author: Atakan
 */

/*
 * system_lighting.c
 *
 *  Created on: Aug 31, 2023
 *      Author: Atakan Ağcakaya
 *      colors: 1 -> Green , 2 -> Red , 3 -> Blue 0 -> RESET state
 */
#include "isik.h"
#include "main.h"
#include "math.h"
/*
 * these parameters is used for configuration of led
 * flag for dma pwm
 * */
int lightFLAG = 0;
int Lednum;
extern TIM_HandleTypeDef htim8;
uint8_t channelFLAG = 0;
/*
 * this func is used for config of brightness and colors and number of LED
 * */
void colorLS(uint8_t red, uint8_t green, uint8_t blue, uint8_t brightness, uint16_t ledNUMBER, uint32_t channel){

	uint8_t data_lighting[ledNUMBER][3];
	if (brightness >= 100){
		brightness=100;
	}
	else {
		brightness=100;
	}

	uint8_t hState = (255* brightness)/100;
	round(hState);

	for (int i = 0; i < ledNUMBER; i++) {
	        data_lighting[i][0] = hState * red / 255;
	        data_lighting[i][1] = hState * green / 255;
	        data_lighting[i][2] = hState * blue / 255;
	    }

	uint16_t pwmData[(24*ledNUMBER)+50]; // 24 bit and 50 us waiting


	uint32_t sendingcolor;
	uint32_t index = 0;

		for(int i = 0 ; i<ledNUMBER; i++){
			sendingcolor = ((data_lighting[i][0]<<16) | (data_lighting[i][1]<<8) | (data_lighting[i][2]));

			for(int j = 23 ; j>=0; j--){
				if (sendingcolor&(1<<j)){
					pwmData[index] = 67;
				}
				else
					pwmData[index] = 33;
				index++;
			}
		}

		for(int i = 0;i<50;i++){
			pwmData[index] = 0;
			index++;
		}
		HAL_TIM_PWM_Start_DMA(&htim8, channel, (uint16_t *)pwmData,index);
		if (channel == TIM_CHANNEL_2){
			channelFLAG = 1;
		}
		else if (channel == TIM_CHANNEL_3) {
			channelFLAG = 0;
		}
		while(!lightFLAG){};
		lightFLAG = 0;

		 HAL_TIM_PWM_Stop_DMA(&htim8, channel);
		 HAL_TIM_Base_Stop(&htim8);
}

/*
 * Function to turn off WS2812B LEDs
 */
void turnOffLS(uint16_t ledNUMBER, uint32_t channel) {
    uint16_t pwmData[(24 * ledNUMBER) + 50]; // 24 bits per LED and 50 us waiting

    // Fill the PWM data with zeros to turn off all LEDs
    for (uint32_t i = 0; i < (24 * ledNUMBER) + 50; i++) {
        pwmData[i] = 0;
    }

    // Add additional zeros for the required waiting time
       for (uint32_t i = (24 * ledNUMBER); i < (24 * ledNUMBER) + 50; i++) {
           pwmData[i] = 0;
       }

    // Start DMA to send zeros and turn off the LEDs
    HAL_TIM_PWM_Start_DMA(&htim8, channel, (uint16_t *)pwmData, (24 * ledNUMBER) + 50);

    // Set the channelFLAG accordingly
    if (channel == TIM_CHANNEL_1) {
        channelFLAG = 1;
    } else {
        channelFLAG = 0;
    }

    // Wait for DMA transfer to complete
    while (!lightFLAG) {
    }
    lightFLAG = 0;

    HAL_TIM_PWM_Stop_DMA(&htim8, channel);
    HAL_TIM_Base_Stop(&htim8);
}




