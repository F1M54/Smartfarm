/*
 * dht11.c
 *
 *  Created on: Nov 25, 2023
 *      Author: Atakan
 */

#include "main.h"
#include "ds18.h"
#include "dht11.h"

uint8_t T_1,T_2,RH_1,RH_2;
uint16_t TMP,RH,SUM;
uint8_t presence1 = 0;

void dhtStart(void){
	outputSet(DHT11_PORT, DHT11_PIN); // set output
	HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, 0); // pull pin 0
	delay(18000); // wait 18ms
	HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, 1); // pull pin 1
	delay(20); // wait 20 us
	inputSet(DHT11_PORT, DHT11_PIN); // set input
}

uint8_t dhtCheck(void){
	uint8_t response1 = 0;
	delay(40); // wait 40 us
	if(!(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN)))
	{
		delay(80);
		if(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))	response1 = 1;
		else response1 = -1;
	}
	while((HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))); // wait pin go 0
	return response1;
}

uint8_t dhtRead(void){

	uint8_t i,j;
	for(j = 0; j<8;j++){
		while (!(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))); // wait for pin go 1
		delay(40); // wait 40 us
		if(!(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))){
			i &= ~(1<<(7-j)); // write 0
		}
		else {
			i |= (1<<(7-j));// i pin is high write 1
		}
		while(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN)); // wait for the pin go 0
	}
	return i;
}

void getDHT11(float *temperature, float *humidity){

	dhtStart();
	presence1 = dhtCheck();
	RH_1 = dhtRead();
	RH_2 = dhtRead();
	T_1 = dhtRead();
	T_2 = dhtRead();
	SUM =dhtRead();
	TMP =  T_1;
	RH = RH_1;

	*temperature = (float)TMP;
	*humidity = (float) SUM;
	HAL_Delay(1000);
}
