/*
 * isik.h
 *
 *  Created on: Dec 8, 2023
 *      Author: Atakan
 */

#ifndef INC_ISIK_H_
#define INC_ISIK_H_

#include "main.h"

void colorLS(uint8_t red, uint8_t green, uint8_t blue, uint8_t brightness, uint16_t ledNUMBER, uint32_t channel);
void turnOffLS(uint16_t ledNUMBER, uint32_t channel);

#endif /* INC_ISIK_H_ */



























