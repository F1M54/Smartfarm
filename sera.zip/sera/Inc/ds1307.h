/*
 * ds1307.h
 *
 *  Created on: Dec 6, 2023
 *      Author: Atakan
 */

#ifndef INC_DS1307_H_
#define INC_DS1307_H_
#include "main.h"
#include "stdbool.h"

#define RTC_I2C 	0x68<<1

#define RTC_SECOND 	0x00
#define RTC_MINUTE 	0x01
#define RTC_HOUR  	0x02

#define RTC_DATE   		0x04
#define RTC_MONTH  		0x05
#define RTC_YEAR   		0x06
#define RTC_UTC_HOUR	0x08
#define RTC_CENTURY 	0x10
#define RTC_TIMEOUT		1000

void initDS1307(I2C_HandleTypeDef *hi2c);
void startDS1307(bool start);
uint8_t stateDS1307(void);

void setDS1307(uint8_t registerDS, uint8_t val);
uint8_t getDS1307(uint8_t registerDS);

uint16_t convertDEC(uint16_t binaryNum);
uint16_t convertBCD(uint16_t decimalNum);

uint8_t dayDS1307(uint8_t *day);
uint8_t monthDS1307(uint8_t *month);
uint16_t yearDS1307(uint16_t *year);

uint8_t hourDS1307(uint8_t *hour);
uint8_t minDS1307(uint8_t *minute);
uint8_t secDS1307(uint8_t *second);
uint8_t timezoneDS1307(uint8_t *timezone);

void setDAY(uint8_t date);
void setMONTH(uint8_t month);
void setYEAR(uint16_t year);

void setHOUR(uint8_t hour);
void setMINUTE(uint8_t minute);
void setSECONDS(uint8_t second);
void setTIMEZONE(int8_t hour);

#endif /* INC_DS1307_H_ */
