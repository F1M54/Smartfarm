/*
 * dht11.h
 *
 *  Created on: Nov 25, 2023
 *      Author: Atakan
 */

#ifndef INC_DHT11_H_
#define INC_DHT11_H_

#define DHT11_PIN GPIO_PIN_10
#define DHT11_PORT GPIOA

void dhtStart(void);
uint8_t dhtCheck(void);
uint8_t dhtRead(void);
void getDHT11(float *temperature, float *humidity);

#endif /* INC_DHT11_H_ */
